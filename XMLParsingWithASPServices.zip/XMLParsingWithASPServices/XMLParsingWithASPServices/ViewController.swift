

import UIKit

class ViewController: UIViewController,XMLParserDelegate {

    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var lblAns: UILabel!
    @IBOutlet weak var lblSubtraction: UILabel!
    @IBOutlet weak var lblMulti: UILabel!
    @IBOutlet weak var lblDivide: UILabel!
    
    
    var strcontent = ""
    let url = URL(string: "http://www.dneonline.com/calculator.asmx")
    
    @IBAction func addition(_ sender: Any)
    {
        
        
        let strbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Add xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text!)</intB></Add></soap:Body></soap:Envelope>"
        
        var request = URLRequest(url: url!)
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue("http://tempuri.org/Add", forHTTPHeaderField: "SOAPAction")
        request.httpMethod = "POST"
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
        let parser = XMLParser(data: data1!)
        parser.delegate = self
        parser.parse()
        }
        datatask.resume()
    }
    
    
    @IBAction func subtraction(_ sender: Any)
    {
        let strbody = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap;Envelope xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><Subtract xmlns=\"http://tempuri.org/\"><intA>\(txt1.text!)</intA><intB>\(txt2.text)</intB></Subtract></soap:Body></soap:Envelope>"
        var request = URLRequest(url: url!)
        request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
        request.addValue("http://tempuri.org/Subtract", forHTTPHeaderField: "SOAPAction")
        request.httpMethod = "POST"
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            let parser = XMLParser(data: data1!)
            parser.delegate = self
        }
        datatask.resume()
    }

    
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if elementName == "AddResult"
        {   DispatchQueue.main.async
            {
                print(self.strcontent)
                self.lblAns.text = self.strcontent
            }
        }
        if elementName == "SubtractResult"
        {
            DispatchQueue.main.async
            {
                print(self.strcontent)
                self.lblSubtraction.text = self.strcontent
            }
        }
    }
    
    
    
    
    
    @IBAction func multiply(_ sender: Any)
    {
        
    }
    
    
    @IBAction func divide(_ sender: Any)
    {
        
    }
    
    
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
            strcontent = string
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
      
    }


}

